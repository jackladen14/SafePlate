/***************************************************************************************************
Author:         Jack Laden
Email:          jackladen13@gmail.com
Class:          EE491 Senior Capstone Design
Last edit:      18 April 2023

 SOME USEFUL DOCUMENTS AND FORUMS FOR THE TIMERS AND ACTION EVENTS:
 https://docs.oracle.com/javase/tutorial/uiswing/misc/timer.html
 https://stackoverflow.com/questions/32028518/repaint-the-panel-repeatedly-after-click-a-button
 https://www.tutorialspoint.com/terminate-the-timer-in-java
***************************************************************************************************/

import java.awt.*;
import java.awt.event.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.border.Border;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.*;
import javax.swing.Timer;

class mainWindow extends JFrame implements ActionListener {

    //thread to connect read ESP32 data in HTML form
    MyThread myThread = new MyThread();

    //Global variables
    int rows = 8;
    int columns = 16;
    int width, height;
    int[] oldData, newData, changedData;
    int thresholdVal = 9;
    int activatedSections;
    Dimension d1, d0;
    JPanel buttonPanel, displayPanel;
    GridLayout grids;
    JLabel[][] displayLabels;
    JTextField currentState;
    JButton bCalibrate, bOn, bOff;
    String greenName = "images/GreenGrid.png";
    String redName = "images/RedGrid.png";
    String yellowName = "images/YellowGrid.png";
    ImageIcon greenCard, redCard, yellowCard;
    Border clearLine;
    boolean readWebsite, alertWin;

    public mainWindow() throws Exception {
        super("SafePlate");

        //dimension of screen
        height = 800;
        width = height * 2;
        d0 = new Dimension(width, height);
        //dimension of Images
        d1 = new Dimension(width / columns - 10, height / rows - 20);

        //initialization for action events
        readWebsite = false;

        //initialize card images
        //GREEN
        BufferedImage green = null;
        try {
            green = ImageIO.read(new File(greenName));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Image g_img = green.getScaledInstance(d1.width, d1.height, Image.SCALE_SMOOTH);
        greenCard = new ImageIcon(g_img);
        //RED
        BufferedImage red = null;
        try {
            red = ImageIO.read(new File(redName));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Image r_img = red.getScaledInstance(d1.width, d1.height, Image.SCALE_SMOOTH);
        redCard = new ImageIcon(r_img);
        //YELLOW
        BufferedImage yellow = null;
        try {
            yellow = ImageIO.read(new File(yellowName));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Image y_img = yellow.getScaledInstance(d1.width, d1.height, Image.SCALE_SMOOTH);
        yellowCard = new ImageIcon(y_img);

        //border color
        clearLine = BorderFactory.createEmptyBorder();

        //initializations
        currentState = new JTextField("Press start to begin reading data.");
        currentState.setEditable(false);
        buttonPanel = new JPanel();
        displayPanel = new JPanel();
        grids = new GridLayout(rows, columns);
        displayPanel.setLayout(grids);
        displayLabels = new JLabel[rows][columns];
        bCalibrate = new JButton("Reset");
        bOn = new JButton("Start");
        bOff = new JButton("Stop");
        oldData = new int[rows*columns];
        newData = new int[rows*columns];
        changedData = new int[rows*columns];
        alertWin = false;

        //creates and adds JLabels to main panel
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {

                //add each button to the card panel
                displayLabels[i][j] = new JLabel();
                displayLabels[i][j].setPreferredSize(d1);
                displayPanel.add(displayLabels[i][j]);
                displayLabels[i][j].setBorder(clearLine);

                //set all cards originally to green
                displayLabels[i][j].setIcon(greenCard);
            }
        }

        //initialize old data to 0 to allow for change in pressure
        for(int i = 0; i < (rows)*(columns); i++)
            oldData[i] = 0;

        //add action listeners for each button on frame
        bCalibrate.addActionListener(this);
        bOn.addActionListener(this);
        bOff.addActionListener(this);

        //add buttons to button panel
        buttonPanel.add(bOn);
        buttonPanel.add(bOff);
        buttonPanel.add(bCalibrate);
        buttonPanel.add(currentState);

        //add panels to frame
        this.setPreferredSize(d0);
        this.add(displayPanel, BorderLayout.NORTH);
        this.add(buttonPanel, BorderLayout.SOUTH);
        this.pack();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        myThread.start();
    }
    
    //action listeners
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        Timer t = new Timer(2000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                if (readWebsite) {
                    newData = myThread.returnPressure();
                    activatedSections = 0;
                    if (newData != null) {
                        currentState.setText("Pressure is being read.");
                        for (int i = 0; i < newData.length; i++) {
                            changedData[i] = newData[i] - oldData[i];
                            int x = i / (columns);
                            int y = i % (columns);

                            //if a section is not reading data
                            if (newData[i] <= 1)
                                displayLabels[x][y].setIcon(yellowCard);
                            //showing pressure
                            else if (changedData[i] >= thresholdVal) {
                                displayLabels[x][y].setIcon(redCard);
                                activatedSections++;
                            }
                            //don't show pressure
                            else
                                displayLabels[x][y].setIcon(greenCard);

                            //open alert screen if fall is detected
                            if (activatedSections >= 6) {
                                if(!alertWin) {
                                    secondWindow secondWin = new secondWindow();
                                    alertWin = true;
                                }
                                activatedSections = 0;
                            }
                        }
                    } else
                        currentState.setText("Connecting to mat...");
                }
            }
        }); t.start();

        if(obj == bOn) {
            readWebsite = true;
        }

        if(obj == bOff) {
            readWebsite = false;
            currentState.setText("Pressure data stopped.");
            alertWin = false;
        }

        if(obj == bCalibrate) {
            oldData = newData;
            currentState.setText("Calibration successful.");
        }
    }
}

class secondWindow {
    JPanel panel1;
    ImageIcon alertCard;
    String alertName = "images/alert.png";
    int height, width;
    Dimension d0;
    JLabel alertLabel;
    JFrame j1;

    public secondWindow() {

        panel1 = new JPanel();
        height = 800;
        width = height;
        d0 = new Dimension(width, height);
        alertLabel = new JLabel();
        j1 = new JFrame("Alert!");

        //get alert image
        BufferedImage alert = null;
        try {
            alert = ImageIO.read(new File(alertName));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Image a_img = alert.getScaledInstance(d0.width, d0.height, Image.SCALE_SMOOTH);
        alertCard = new ImageIcon(a_img);
        //add image to JLabel
        alertLabel.setIcon(alertCard);

        j1.setPreferredSize(d0);
        j1.add(alertLabel);
        j1.pack();
        j1.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        j1.setVisible(true);
    }
}

public class Main {
    public static void main(String[] args) throws Exception {
         mainWindow win = new mainWindow();
         win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
