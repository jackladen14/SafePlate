import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class MyThread extends Thread {

    public static volatile int[] newPressure;
    public static volatile int[] arr;

    public MyThread() throws IOException {
    }

    public void run() {
        while (true) {
            try {
                newPressure = getData();
                for (int i = 0; i < newPressure.length; i++) {
                    //System.out.println(newPressure[i]);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static int[] getData() throws Exception {
        URL oracle = new URL("http://10.45.156.164");
        URLConnection yc = oracle.openConnection();
        BufferedReader in = new BufferedReader(new InputStreamReader(
                yc.getInputStream()));
        String inputLine = "";
        String readData;
        StringBuilder test = new StringBuilder();

        String tempString1, tempString2, tempString3, tempString4;
        String replaceString1 =  "<body><h1>Pressure Data ESP32</h1><ol type=1>";
        String replaceString2 = "<li>";
        String replaceString3 = "<i>";
        String replaceString4 = "</ol></body></html>";

        if (in.readLine() != null) {
            while((readData = in.readLine()) != null) {
                test.append(readData);
                inputLine = test.toString();
                System.out.println(inputLine);
            }
            tempString1 = inputLine.replaceAll(replaceString1, "");
            //System.out.println(tempString1);
            tempString2 = tempString1;
            tempString2 = tempString2.replaceAll(replaceString2, "");
            //System.out.println(tempString2);
            tempString3 = tempString2;
            tempString3 = tempString3.replaceAll(replaceString3, " ");
            //System.out.println(tempString3);
            tempString4 = tempString3;
            tempString4 = tempString4.replaceAll(replaceString4, "");
            //System.out.println(tempString4);
            String[] str = tempString4.split(" ");
            arr = new int[str.length];
            newPressure = new int[arr.length];
            for (int i = 0; i < str.length; i++) {
                arr[i] = Integer.parseInt(str[i]);
            }
            return arr;
        }
        in.close();
        return null;
    }

    public int[] returnPressure() {
        for (int j : newPressure) System.out.println(j);
        return newPressure;
    }
}
